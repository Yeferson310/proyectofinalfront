const express = require("express");

var cors = require("cors");
const app = express();
app.use(express.json());
app.use(cors());
const port = 3001;

app.post("/login", (req, res) => {
  let usuario = req.body.usuario;
  let clave = req.body.clave;
  // to do : autenticar en base de datos en base de datos hacer un select , token jwt sino existe mensaje con codigo
  res.status(200);
  res.send(JSON.stringify({ msg: "OK" }));
});

app.get("/pkmn", (req, res) => {
  res.setHeader("Content-Type", "application/json");
  res.send(
    JSON.stringify({
      pokemons: [
        {
          id: 1,
          idd: "001",
          imagen: "/img/bulbasaur.png",
          color1: "#74cb48",
          color2: "#A43E9E",
          nombre: "Bulbasaur",
          types: {
            type1: "Grass",
            type2: "Poison",
          },
          weight: "6.9 Kg",
          height: "0.7 m",
          moves: "Chlorophyll Overgrow",
          description:
            "There is a plant seed on its back right from the day this Pokémon is born. The seed slowly grows larger.",
          stats: {
            hp: "045",
            atk: "049",
            def: "049",
            satk: "065",
            sdef: "065",
            spd: "045",
          },
        },
        {
          id: 2,
          idd: "004",
          imagen: "/img/charmander.png",
          color1: "#f57d31",
          nombre: "Charmander",
          types: {
            type1: "Fire",
          },
          weight: "8.5Kg",
          height: "0.6m",
          moves: "Mega-Punch, Fire-Punch",
          description:
            "It has a preference for hot things. When it rains, steam is said to spout from the tip of its tail.",
          stats: {
            hp: "039",
            atk: "052",
            def: "043",
            satk: "060",
            sdef: "060",
            spd: "065",
          },
        },
        {
          id: 3,
          idd: "007",
          imagen: "/img/squirtle.png",
          color1: "#6493EB",
          nombre: "Squirtle",
          types: {
            type1: "Water",
          },
          weight: "9.0Kg",
          height: "0.5m",
          moves: "Rain-Dish",
          description:
            "When it retracts its long neck into its shell, it squirts out water with vigorous force.",
          stats: {
            hp: "044",
            atk: "048",
            def: "065",
            satk: "050",
            sdef: "064",
            spd: "043",
          },
        },
        {
          id: 4,
          idd: "012",
          imagen: "/img/butterfree.png",
          color1: "#6493EB",
          color2: "#A891EC",
          nombre: "Butterfree",
          types: {
            type1: "Bug",
            type2: "Flying",
          },
          weight: "32.0Kg",
          height: "1.1m",
          moves: "Compound-Eyes, Tinted-Lens",
          description:
            "In battle, it flaps its wings at great speed to release highly toxic dust into the air.",
          stats: {
            hp: "060",
            atk: "045",
            def: "090",
            satk: "090",
            sdef: "080",
            spd: "080",
          },
        },
        {
          id: 5,
          idd: "025",
          imagen: "/img/pikachu.png",
          color1: "#F9CF30",
          nombre: "Pikachu",
          types: {
            type1: "Electric",
          },
          weight: "6.0Kg",
          height: "0.4m",
          moves: "Mega-Punch, Pay-Day",
          description:
            "Pikachu that can generate powerful electricity have cheek sacs that are extra soft and super stretchy.",
          stats: {
            hp: "035",
            atk: "055",
            def: "040",
            satk: "050",
            sdef: "050",
            spd: "050",
          },
        },
        {
          id: 6,
          idd: "092",
          imagen: "/img/gastly.png",
          color1: "#70559B",
          color2: "#666666",
          nombre: "Gastly",
          types: {
            type1: "Ghost",
            type2: "Type",
          },
          weight: "0.1 Kg",
          height: "1.3 m",
          moves: "Levitate",
          description:
            "Born from gases, anyone would faint if engulfed by its gaseous body, which contains poison.",
          stats: {
            hp: "030",
            atk: "005",
            def: "030",
            satk: "100",
            sdef: "032",
            spd: "080",
          },
        },
        {
          id: 7,
          idd: "132",
          imagen: "/img/ditto.png",
          color1: "#AAA67F",
          nombre: "Ditto",
          types: {
            type1: "Normal",
          },
          weight: "4.0 Kg",
          height: "0.3 m",
          moves: "Limber, Imposter",
          description:
            "It can reconstitute its entire cellular structure to change into what it sees, but it returns to normal when it relaxes.",
          stats: {
            hp: "048",
            atk: "048",
            def: "048",
            satk: "048",
            sdef: "048",
            spd: "048",
          },
        },
        {
          id: 8,
          idd: "152",
          imagen: "/img/mew.png",
          color1: "#FB5584",
          nombre: "Mew",
          types: {
            type1: "Psychic",
          },
          weight: "4.0 Kg",
          height: "0.4 m",
          moves: "Synchronize",
          description:
            "When viewed through a microscope, this Pokémon’s short, fine, delicate hair can be seen.",
          stats: {
            hp: "100",
            atk: "100",
            def: "100",
            satk: "100",
            sdef: "100",
            spd: "100",
          },
        },
        {
          id: 9,
          idd: "304",
          imagen: "/img/aron.png",
          color1: "#B7B9D0",
          color2: "#B69E31",
          nombre: "Aron",
          types: {
            type1: "Steel",
            type2: "Rock",
          },
          weight: "60.0 Kg",
          height: "0.4 m",
          moves: "Sturdy, Rock-Head",
          description:
            "It eats iron ore - and sometimes railroad tracks - to build up the steel armor that protects its body.",
          stats: {
            hp: "050",
            atk: "070",
            def: "100",
            satk: "040",
            sdef: "040",
            spd: "030",
          },
        },
      ],
    })
  );
});
app.get("/pkmn/:id_pkmn", function (req, res) {
  let pokemones = [
    {
      id: 1,
      idd: "001",
      imagen: "/img/bulbasaur.png",
      color1: "#74cb48",
      color2: "#A43E9E",
      nombre: "Bulbasaur",
      types: {
        type1: "Grass",
        type2: "Poison",
      },
      weight: "6.9 Kg",
      height: "0.7 m",
      moves: "Chlorophyll Overgrow",
      description:
        "There is a plant seed on its back right from the day this Pokémon is born. The seed slowly grows larger.",
      stats: {
        hp: "045",
        atk: "049",
        def: "049",
        satk: "065",
        sdef: "065",
        spd: "045",
      },
    },
    {
      id: 2,
      idd: "004",
      imagen: "/img/charmander.png",
      color1: "#f57d31",
      nombre: "Charmander",
      types: {
        type1: "Fire",
      },
      weight: "8.5 Kg",
      height: "0.6 m",
      moves: "Mega-Punch, Fire-Punch",
      description:
        "It has a preference for hot things. When it rains, steam is said to spout from the tip of its tail.",
      stats: {
        hp: "039",
        atk: "052",
        def: "043",
        satk: "060",
        sdef: "060",
        spd: "065",
      },
    },
    {
      id: 3,
      idd: "007",
      imagen: "/img/squirtle.png",
      color1: "#6493EB",
      nombre: "Squirtle",
      types: {
        type1: "Water",
      },
      weight: "9.0 Kg",
      height: "0.5 m",
      moves: "Rain-Dish",
      description:
        "When it retracts its long neck into its shell, it squirts out water with vigorous force.",
      stats: {
        hp: "044",
        atk: "048",
        def: "065",
        satk: "050",
        sdef: "064",
        spd: "043",
      },
    },
    {
      id: 4,
      idd: "012",
      imagen: "/img/butterfree.png",
      color1: "#6493EB",
      color2: "#A891EC",
      nombre: "Butterfree",
      types: {
        type1: "Bug",
        type2: "Flying",
      },
      weight: "32.0 Kg",
      height: "1.1 m",
      moves: "Compound-Eyes, Tinted-Lens",
      description:
        "In battle, it flaps its wings at great speed to release highly toxic dust into the air.",
      stats: {
        hp: "060",
        atk: "045",
        def: "050",
        satk: "090",
        sdef: "080",
        spd: "070",
      },
    },
    {
      id: 5,
      idd: "025",
      imagen: "/img/pikachu.png",
      color1: "#F9CF30",
      nombre: "Pikachu",
      types: {
        type1: "Electric",
      },
      weight: "6.0 Kg",
      height: "0.4 m",
      moves: "Mega-Punch, Pay-Day",
      description:
        "Pikachu that can generate powerful electricity have cheek sacs that are extra soft and super stretchy.",
      stats: {
        hp: "035",
        atk: "055",
        def: "040",
        satk: "050",
        sdef: "050",
        spd: "090",
      },
    },
    {
      id: 6,
      idd: "092",
      imagen: "/img/gastly.png",
      color1: "#70559B",
      color2: "#666666",
      nombre: "Gastly",
      types: {
        type1: "Ghost",
        type2: "Type",
      },
      weight: "0.1 Kg",
      height: "1.3 m",
      moves: "Levitate",
      description:
        "Born from gases, anyone would faint if engulfed by its gaseous body, which contains poison.",
      stats: {
        hp: "030",
        atk: "005",
        def: "030",
        satk: "100",
        sdef: "032",
        spd: "080",
      },
    },
    {
      id: 7,
      idd: "132",
      imagen: "/img/ditto.png",
      color1: "#AAA67F",
      nombre: "Ditto",
      types: {
        type1: "Normal",
      },
      weight: "4.0 Kg",
      height: "0.3 m",
      moves: "Limber, Imposter",
      description:
        "It can reconstitute its entire cellular structure to change into what it sees, but it returns to normal when it relaxes.",
      stats: {
        hp: "048",
        atk: "048",
        def: "048",
        satk: "048",
        sdef: "048",
        spd: "048",
      },
    },
    {
      id: 8,
      idd: "152",
      imagen: "/img/mew.png",
      color1: "#FB5584",
      nombre: "Mew",
      types: {
        type1: "Psychic",
      },
      weight: "4.0 Kg",
      height: "0.4 m",
      moves: "Synchronize",
      description:
        "When viewed through a microscope, this Pokémon’s short, fine, delicate hair can be seen.",
      stats: {
        hp: "100",
        atk: "100",
        def: "100",
        satk: "100",
        sdef: "100",
        spd: "100",
      },
    },
    {
      id: 9,
      idd: "304",
      imagen: "/img/aron.png",
      color1: "#B7B9D0",
      color2: "#B69E31",
      nombre: "Aron",
      types: {
        type1: "Steel",
        type2: "Rock",
      },
      weight: "60.0 Kg",
      height: "0.4 m",
      moves: "Sturdy, Rock-Head",
      description:
        "It eats iron ore - and sometimes railroad tracks - to build up the steel armor that protects its body.",
      stats: {
        hp: "050",
        atk: "070",
        def: "100",
        satk: "040",
        sdef: "040",
        spd: "030",
      },
    },
  ];
  let pokemon = "";
  for (let i = 0; i < pokemones.length; i++) {
    if (pokemones[i].id == req.params.id_pkmn) {
      pokemon = pokemones[i];
      break;
    }
  }// en una carpeta y controlers 
  res.status(200);
  res.send(JSON.stringify(pokemon));
  
});
app.get("/pokemonstotal", (req, res) => {
  // to do : traer el total de pokemones de la tabla
  let total = 9;
  res.status(200);
  res.send(JSON.stringify({ length: total }));
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
